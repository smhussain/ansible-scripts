#!/bin/bash

# Usage $0 <ign-config-file> <hostname> <domain> <ip-addr> <ip-prefix> <ip-gw> <ip-dns1> <ip-dns2>
# For Bootstrap node pass \"append_bootstrap.ign\" as the ignition config file!

## Examples:

# Bootstrap node
# ./modify-ign-configs.sh append_bootstrap.ign bootstrap0 ocp43.icds.online 192.168.68.79 24 192.168.68.1 192.168.68.76 8.8.8.8

# Master nodes
# ./modify-ign-configs.sh master.ign master0 ocp43.icds.online 192.168.68.80 24 192.168.68.1 192.168.68.76 8.8.8.8
# ./modify-ign-configs.sh master.ign master1 ocp43.icds.online 192.168.68.80 24 192.168.68.1 192.168.68.76 8.8.8.8
# ./modify-ign-configs.sh master.ign master2 ocp43.icds.online 192.168.68.80 24 192.168.68.1 192.168.68.76 8.8.8.8

# Worker nodes
# ./modify-ign-configs.sh worker.ign worker0 ocp43.icds.online 192.168.68.88 24 192.168.68.1 192.168.68.76 8.8.8.8
# ./modify-ign-configs.sh worker.ign worker1 ocp43.icds.online 192.168.68.89 24 192.168.68.1 192.168.68.76 8.8.8.8

function log()
{
  if [[ ${DEBUG} ]];
  then
    echo $*
  fi  
}

function valid_ip()
{
    local  ip=$1
    local  stat=1

    if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        OIFS=$IFS
        IFS='.'
        ip=($ip)
        IFS=$OIFS
        [[ ${ip[0]} -le 255 && ${ip[1]} -le 255 \
            && ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
        stat=$?
    fi
    return $stat
}

generate_baseconfig ()
{
  log "Generating Base config file \"${1}.modified\""
  b64_config=`cat ${1} | base64 -w 0`
  cat > ${1}.modified <<EOF
  {
    "ignition": {
        "config": {
            "append": [
                {
                    "source": "data:text/plain;charset=utf-8;base64,${b64_config}",
                    "verification": {}
                }
            ]
        },
        "timeouts": {},
        "version": "2.1.0"
    },
    "networkd": {},
    "passwd": {},
    "storage": {},
    "systemd": {}
}
EOF

}

generate_hostname ()
{
  log "Adding hostname config"
  b64_hostname=`echo $2 | base64 -w 0`
  change_me=`echo "data:text/plain;charset=utf-8;base64,${b64_hostname}"`
  tmpfile=$(mktemp)
  jq --arg CHANGEME ${change_me} '.storage.files |= .+ [{"filesystem":"root", "group": {}, "path": "/etc/hostname", "user": {}, "contents": {"source":$CHANGEME, "verification": {}}, "mode": 420}]' < ${1} > "${tmpfile}"
  mv -f ${tmpfile} ${1}
}

generate_network ()
{
  log "Adding Network config"

  networktmpl=$(mktemp)
  cat > ${networktmpl} << EOF
TYPE=Ethernet
BOOTPROTO=none
NAME=ens192
DEVICE=ens192
ONBOOT=yes
IPADDR=__FILL_IN_IPADDRESS__
PREFIX=__FILL_IN_IP_PREFIX__
GATEWAY=__FILL_IN_IP_GW__
DOMAIN=__FILL_IN_DOMAIN__
DNS1=__FILL_IN_IP_DNS1__
DNS2=__FILL_IN_IP_DNS2__

EOF

  sed -e "s/__FILL_IN_DOMAIN__/${3}/g" \
      -e "s/__FILL_IN_IPADDRESS__/${4}/g" \
      -e "s/__FILL_IN_IP_PREFIX__/${5}/g" \
      -e "s/__FILL_IN_IP_GW__/${6}/g" \
      -e "s/__FILL_IN_IP_DNS1__/${7}/g" \
      -e "s/__FILL_IN_IP_DNS2__/${8}/g" ${networktmpl} > ${networktmpl}.replaced
  b64_network=`cat ${networktmpl}.replaced | base64 -w 0`
  rm -f ${networktmpl}.replaced

  change_me=`echo "data:text/plain;charset=utf-8;base64,${b64_network}"`
  tmpfile=$(mktemp)
  jq --arg CHANGEME ${change_me} '.storage.files |= .+ [{"filesystem":"root", "group": {}, "path": "/etc/sysconfig/network-scripts/ifcfg-ens192", "user": {}, "contents": {"source":$CHANGEME, "verification": {}}, "mode": 420}]'  < ${1} > "${tmpfile}"
  mv -f ${tmpfile} ${1}
}

generate_systemd() {
  log "Adding SystemD config"
  tmpfile=$(mktemp)
  jq '.systemd.units |= .+ [{"contents":"[Unit]\nConditionFirstBoot=yes\n[Service]\nType=idle\nExecStart=/sbin/reboot\n[Install]\nWantedBy=multi-user.target\n", "enabled": true, "name": "restart.service"}]'  < ${1} > "${tmpfile}"
  mv -f ${tmpfile} ${1}
}

# check for jq binary
status=`which jq`
if [[ $? -ne 0 ]];
then
  echo "This script requires jq command to function. Download from https://stedolan.github.io/jq/download/"
  echo "Exiting..."
  exit -1
fi

if [[ $# -lt 8 ]];
then
  echo "Error: Insufficient arguments!"
  echo ""
  echo "Usage $0 <ign-config-file> <hostname> <domain> <ip-addr> <ip-prefix> <ip-gw> <ip-dns1> <ip-dns2>"
  echo "For Bootstrap node pass \"append_bootstrap.ign\" as the ignition config file!"
  echo "Example: $0 master.ign master0 ocp43.icds.online 192.168.68.80 24 192.168.68.1 192.168.68.76 8.8.8.8"
  exit 1
fi

# Base ignition file to amend
base_ignition_file=${1}
if [[ ! -f ${base_ignition_file} ]];
then
   echo "Ignition file \"${base_ignition_file}\" not present!"
   exit 2
fi

# Hostname
host_name=$2

# Domain Name
domain_name=$3

# Ip Address
ip_address=${4}
valid_ip $ip_address
if [[ $? -ne 0 ]];
then
  echo "Invalid IP Address \"${ip_address}\" specified"
  exit 3
fi

# IP Prefix
ip_prefix=$5

# Gateway IP
ip_gw=${6}
valid_ip ${ip_gw}
if [[ $? -ne 0 ]];
then
  echo "Invalid Gateway IP \"${ip_gw}\" specified."
  exit 3
fi

# DNS1
ip_dns1=${7}
valid_ip ${ip_dns1}
if [[ $? -ne 0 ]];
then
  echo "Invalid DNS1 \"${ip_dns1}\" specified"
  exit 3
fi

# DNS2
ip_dns2=${8}
valid_ip ${ip_dns2}
if [[ $? -ne 0 ]];
then
  echo "Invalid DNS2 \"${ip_dns2}\" specified"
  exit 3
fi

log "Modifying ignition config for $1"

if [[ ! ${host_name:0:4} == "boot" ]];
then
  generate_baseconfig ${base_ignition_file}
else
  # For the Bootstrap node the ignition file is stored in the httpd / nginx web server
  # hence can additional config to the existing append_bootstrap.ign ignition config file
  log "Processing for bootstrap node"
  cp ${base_ignition_file} ${base_ignition_file}.modified
fi

ignition_file=${base_ignition_file}.modified

generate_hostname ${ignition_file} ${host_name}
generate_network ${ignition_file} ${host_name} ${domain_name} ${ip_address} ${ip_prefix} ${ip_gw} ${ip_dns1} ${ip_dns2}
generate_systemd ${ignition_file}

log "Modified ignition config file saved \"${ignition_file}\" for node ${host_name}"
cat ${ignition_file} | base64 -w 0 > ${ignition_file}.b64

mv -f ${ignition_file} ${host_name}.ign
mv -f ${ignition_file}.b64 ${host_name}.ign.b64
log "Modified ignition config file (base64 encoding) saved \"${host_name}.ign.b64\" for node ${host_name}"

log "Done."
#cat ${ignition_file}.b64

# End
