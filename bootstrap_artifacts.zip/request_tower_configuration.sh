#!/bin/bash

fatal() {
  if [ -n "${2}" ]; then
    echo -e "Error: ${2}"
  fi
  exit ${1}
}

usage() {
cat << EOF
Usage: $0 <options>

Request server configuration from Ansible Tower.

OPTIONS:
   -h      Show this message
   -s      Tower server (e.g. https://tower.example.com) (required)
   -k      Allow insecure SSL connections and transfers
   -c      Host config key (required)
   -t      Job template ID (required)
   -e      Extra variables
EOF
}

# Initialize variables
INSECURE=""
CURL_H_VARS="''"
JQ="/usr/local/bin/jq"

# Parse arguments
while getopts "hks:c:t:s:e:a:" OPTION
do
  case ${OPTION} in
    h)
      usage
      exit 1
      ;;
    s)
      TOWER_SERVER=${OPTARG}
      ;;
    k)
      INSECURE="-k"
      ;;
    c)
      HOST_CFG_KEY=${OPTARG}
      ;;
    t)
      TEMPLATE_ID=${OPTARG}
      ;;
    e)
      EXTRA_VARS=${OPTARG}
      ;;
    a)
      CURL_H_VARS=${OPTARG}
      ;;
    ?)
      usage
      exit
      ;;
  esac
done

# Validate required arguments
test -z ${TOWER_SERVER} && fatal 1 "Missing required -s argument"
[[ "${TOWER_SERVER}" =~ ^https?:// ]] || fatal 1 "Tower server must begin with http:// or https://"
test -z ${HOST_CFG_KEY} && fatal 1 "Missing required -c argument"
test -z ${TEMPLATE_ID} && fatal 1 "Missing required -t argument"

# Generate curl --data parameter
if [ -n "${EXTRA_VARS}" ]; then
  CURL_DATA="{\"host_config_key\": \"${HOST_CFG_KEY}\", \"extra_vars\": \"${EXTRA_VARS}\"}"
else
  CURL_DATA="{\"host_config_key\": \"${HOST_CFG_KEY}\"}"
fi

# Success on any 2xx status received, failure on only 404 status received, retry any other status every min for up to 10 min
RETRY_ATTEMPTS=20
ATTEMPT=0
while [[ ${ATTEMPT} -lt ${RETRY_ATTEMPTS} ]]
do
  set -o pipefail
  
  echo "Trying ${ATTEMPT} of ${RETRY_ATTEMPTS}..."
  CURL_CMD_OUTPUT=$(curl ${INSECURE} -s -k -i -X POST -H ${CURL_H_VARS} -H 'Content-Type:application/json' --data "$CURL_DATA" ${TOWER_SERVER}/api/v2/job_templates/${TEMPLATE_ID}/callback/ 2>&1 | tr -d '\r')
  CURL_RC=$?
  if [ ${CURL_RC} -ne 0 ]; then
    echo "Error: RC=${CURL_RC} Command output: ${CURL_CMD_OUTPUT}"
    fatal ${CURL_RC} "curl exited with ${CURL_RC}, halting."
  fi

  HTTP_STATUS=`echo ${CURL_CMD_OUTPUT} | head -n1 | awk '{print $2}'`
  if [[ ${HTTP_STATUS} =~ ^2[0-9]+$ ]]; then
    JOB_URL=`echo ${CURL_CMD_OUTPUT} | grep -oP "Location: \K.*" | cut -d" " -f1`
    echo "HTTP_STATUS=${HTTP_STATUS} JOB_URL=${JOB_URL}"
    break
  elif [[ ${HTTP_STATUS} =~ ^404$ ]]; then
    echo "Error: HTTP_STATUS=${HTTP_STATUS} Command output: ${CURL_CMD_OUTPUT}"
    fatal 1 "Failed: ${HTTP_STATUS} received, encountered problem, halting."
  else
    ATTEMPT=$((ATTEMPT + 1))
    echo "Failed: ${HTTP_STATUS} received, executing retry #${ATTEMPT} in 1 minute."
    echo "Error: HTTP_STATUS=${HTTP_STATUS} Command output: ${CURL_CMD_OUTPUT}"
    echo "Trying again in 30 seconds..."
    sleep 30
  fi
done

if [[ $JOB_URL ]]; then
  # Get auditor auth token to check status
  #CURL_ACMD_OUTPUT=$(curl -k -s --location --request POST ${TOWER_SERVER}/api/v2/authtoken/ --header 'Content-Type: application/json' --data '{"username": "towerauditor","password": "auditor123"}')
  #CURL_RC=$?
  #if [[ ${CURL_RC} -eq 0 ]]; then
  #  TOWER_TOKEN=`echo ${CURL_ACMD_OUTPUT} | ${JQ} -r '.token'`
  #  if [[ ($? -ne 0) || (${TOWER_TOKEN} = "null") ]]; then
  #    echo ${CURL_ACMD_OUTPUT}
  #    fatal 2 "Unable to get auditor access token to Ansible tower. Exiting."
  #  fi
  #else
  #    echo ${CURL_ACMD_OUTPUT}
  #    fatal 2 "Unable to login to Ansible tower. Exiting."
  #fi
  #echo "Retrieved auditor access token to tower instance sucessfully"
  
  echo "Using existing auditor access token to tower instance sucessfully"

  RETRY_ATTEMPTS=30
  ATTEMPT=0
  job_failed_status="true"
  job_elapsed_time=0

  echo "Monitoring status of job ${JOB_URL}"
  while [[ ${ATTEMPT} -lt ${RETRY_ATTEMPTS} ]]
  do
    sleep 30
    CURL_JCMD_OUTPUT=$(curl --location -k -s --request GET ${TOWER_SERVER}${JOB_URL} --header 'Authorization: Bearer suw3yANwX4FJ5ep6DOMc2hfpdpJAOp' --header 'Content-Type: application/json')
    CURL_RC=$?
    if [ ${CURL_RC} -ne 0 ]; then
      echo "Error in fetching job status: RC=${CURL_RC} Command output: ${CURL_JCMD_OUTPUT}"
      fatal ${CURL_RC} "curl exited with ${CURL_RC}, halting."
    fi

    job_status=`echo ${CURL_JCMD_OUTPUT} | ${JQ} -r '.status'`
    if [[ ${job_status} = "successful" ]]; then
      echo "Job completion ${job_status} for job ${JOB_URL}"
      job_failed_status=`echo ${CURL_JCMD_OUTPUT} | ${JQ} -r '.failed'`
      job_elapsed_time=`echo ${CURL_JCMD_OUTPUT} | ${JQ} -r '.elapsed'`
      break
    elif [[ ${job_status} = "canceled" || ${job_status} = "failed" ]]; then
      echo "Job ${job_status} for job ${JOB_URL}"
      job_failed_status=`echo ${CURL_JCMD_OUTPUT} | ${JQ} -r '.failed'`
      break
    elif [[ ${job_status} = "failed" ]]; then
      echo "Job ${job_status} for job ${JOB_URL}"
      job_failed_status=`echo ${CURL_JCMD_OUTPUT} | ${JQ} -r '.failed'`
      job_started=`echo ${CURL_JCMD_OUTPUT} | ${JQ} -r '.started'`
      job_explanation=`echo ${CURL_JCMD_OUTPUT} | ${JQ} -r '.job_explanation'`
      if [[ ${job_started} = "null" ]]; then
        echo "Failed to sync inventory: ${job_explanation}"
        fatal 909 "failed to sync inventory. can re-try again."
      fi
      break
    elif [[ ${job_status} = "running" ]]; then
      ATTEMPT=$((ATTEMPT + 1))
    else
      ATTEMPT=$((ATTEMPT + 1))
      echo "Job status ${job_status} for ${JOB_URL}"
    fi
    echo "Waiting for job completion... status=${job_status}. Trying ${ATTEMPT} of ${RETRY_ATTEMPTS} [$((ATTEMPT * 30)) seconds elapsed]"
  done

  if [[ ${job_failed_status} = "true" ]]; then
    echo ${CURL_JCMD_OUTPUT}
    fatal 4 "Failed to complete the job"
  else
    echo "Job ${JOB_URL} completed in ${job_elapsed_time} seconds"
  fi
else
  # No Job URL 
  echo ${CURL_CMD_OUTPUT}
  fatal 5 "Failed: No jobs started. Exiting."
fi

# End
