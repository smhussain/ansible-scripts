#!/bin/bash
nodejs $APP_NAME